import React, { useState } from 'react';

const cornerPieces = [
  ["11", "12", "13"], ["21", "22", "23"], ["31", "32", "33"],
  ["41", "42", "43"], ["51", "52", "53"], ["61", "62", "63"],
  ["71", "72", "73"], ["81", "82", "83"]
];

const edgePieces = [
  ["11", "12"], ["21", "23"], ["31", "32"], ["41", "43"], ["52", "53"],
  ["62", "63"], ["72", "73"], ["82", "83"], ["91", "92"],
  ["01", "03"], ["百1", "百2"], ["千1", "千3"]
];

function getRandomPieces(pieces, count) {
  const selected = [...pieces].sort(() => 0.5 - Math.random()).slice(0, count);
  return selected.map(p => p[Math.floor(Math.random() * p.length)]);
}

export default function BLDMemoTrainer() {
  const [cornerCount, setCornerCount] = useState(5);
  const [edgeCount, setEdgeCount] = useState(5);
  const [cornerPath, setCornerPath] = useState([]);
  const [edgePath, setEdgePath] = useState([]);
  const [userCorner, setUserCorner] = useState('');
  const [userEdge, setUserEdge] = useState('');
  const [result, setResult] = useState('');
  const [showAnswer, setShowAnswer] = useState(true);

  const generatePaths = () => {
    setCornerPath(getRandomPieces(cornerPieces, cornerCount));
    setEdgePath(getRandomPieces(edgePieces, edgeCount));
    setResult('');
    setUserCorner('');
    setUserEdge('');
    setShowAnswer(false);
  };

  const checkAnswers = () => {
    const userCorners = userCorner.trim().split(/\s+/);
    const userEdges = userEdge.trim().split(/\s+/);
    const correctCorner = cornerPath.every(c => userCorners.includes(c));
    const correctEdge = edgePath.every(e => userEdges.includes(e));
    setResult(correctCorner && correctEdge ? '✅ 驗證成功！' : '❌ 有錯誤，請再檢查！');
  };

  return (
    <div className="p-4 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold">🧠 盲解魔方記憶練習器（網頁版）</h1>

      <div className="flex gap-4 flex-wrap items-center">
        <label>角塊數：
          <select value={cornerCount} onChange={e => setCornerCount(Number(e.target.value))}>
            {[...Array(8)].map((_, i) => <option key={i + 1}>{i + 1}</option>)}
          </select>
        </label>
        <label>邊塊數：
          <select value={edgeCount} onChange={e => setEdgeCount(Number(e.target.value))}>
            {[...Array(12)].map((_, i) => <option key={i + 1}>{i + 1}</option>)}
          </select>
        </label>
        <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={generatePaths}>生成題目</button>
        <label className="flex items-center gap-1">
          <input type="checkbox" checked={showAnswer} onChange={e => setShowAnswer(e.target.checked)} /> 顯示答案
        </label>
      </div>

      {showAnswer && (
        <div>
          <p className="text-lg">角塊路徑：<span className="font-mono">{cornerPath.join(' → ')}</span></p>
          <p className="text-lg">邊塊路徑：<span className="font-mono">{edgePath.join(' → ')}</span></p>
        </div>
      )}

      <div>
        <input
          type="text"
          className="w-full border p-2 rounded mb-2"
          placeholder="輸入你記得的角塊（空格分隔）"
          value={userCorner}
          onChange={e => setUserCorner(e.target.value)}
        />
        <input
          type="text"
          className="w-full border p-2 rounded mb-2"
          placeholder="輸入你記得的邊塊（空格分隔）"
          value={userEdge}
          onChange={e => setUserEdge(e.target.value)}
        />
        <button className="bg-green-600 text-white px-4 py-2 rounded w-full" onClick={checkAnswers}>驗證答案</button>
      </div>

      {result && <div className="text-xl font-semibold text-center">{result}</div>}
    </div>
  );
}